// Click event on button
$('#btn-1').click(function () {
    $(this).removeClass('btn-primary').addClass('btn-danger').text('Register');
});

// DBLClick event on button
$('#btn-2').dblclick(function () {
    $(this).removeClass('btn-danger').addClass('btn-primary').text('login');
});

// toggle effect
$('#btn-3').click(function () {
    if($(this).text() === 'login'){
        $(this).removeClass('btn-primary').addClass('btn-danger').text('register');
    }
    else{
        $(this).removeClass('btn-danger').addClass('btn-primary').text('login');
    }
});

// keyup event
$('#text-box').keyup(function() {
    $('#msg-1').text($(this).val());
});

// sms app
$('#text-area').keyup(function() {
    $('#char-count').text(100 - $(this).val().length);
});

// Change event on select box
$('#select-box').change(function() {
    $('#selected-option').text($(this).val());
});

// change event
$('#check-box').change(function () {
    let passwordBox = $('#password-box');
    let attribute = passwordBox.attr('type');
    if(attribute === 'password'){
        passwordBox.attr('type','text');
    }
    else{
        passwordBox.attr('type','password');
    }
});