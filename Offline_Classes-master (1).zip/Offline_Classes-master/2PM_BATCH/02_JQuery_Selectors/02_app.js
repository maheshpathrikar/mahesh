// Tag Selector , id selector , class selector
$('.lead').click(function() {
   $(this).css({
       backgroundColor : 'orange',
       padding : '10px',
       boxShadow : '0 0 10px black',
       borderRadius : '20px'
   });
});

// Attribute Selector
$('input[type="text"]').focus(function () {
    $(this).css({
        backgroundColor: 'red',
        color : 'white'
    });
}).blur(function () {
    $(this).css({
        backgroundColor: 'white',
        color : 'black'
    });
});

$('input[type="password"]').focus(function () {
    $(this).css({
        backgroundColor: 'blueviolet',
        color : 'white'
    });
}).blur(function () {
    $(this).css({
        backgroundColor: 'white',
        color : 'black'
    });
});

